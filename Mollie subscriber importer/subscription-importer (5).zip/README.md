# Subscription Importer

WP-CLI plugin for migrating Pronamic/Mollie subscriptions into FluentCart. Test-only — live Mollie API is blocked.

---

## Requirements

- WordPress + FluentCart installed and active
- Mollie gateway active in FluentCart
- WP-CLI available
- `wp-config.php` contains:

```php
define( 'SUBSCRIPTION_MOLLIE_TEST_API_KEY', 'test_...' );
define( 'SUBSCRIPTION_MOLLIE_SSL_VERIFY', false ); // local/Windows only
```

---

## Why dummy IDs exist

The sanitized export JSON replaces real Mollie customer and mandate IDs with dummy placeholders:

```json
"mollie": {
  "customer_id": "cst_dummy_23054b978858",
  "mandate_id":  "mdt_dummy_7673a0856a2f"
}
```

These dummy IDs **do not exist in Mollie**. Before importing, you must run `simulate-mollie` to create real Mollie Test customers and mandates and store a mapping in `wp_mollie_test_mapping`. The importer then uses the mapped test IDs for all Mollie API calls and stores them in FluentCart — so what you see in the FluentCart admin matches what appears in the Mollie Test dashboard.

---

## Required workflow

### Step 1 — Verify Mollie key is configured

```bash
wp subs mollie-config
```

Expected output: `Success: Mollie test API key resolved: test_...`

### Step 2 — Validate the export file

```bash
wp subs validate --file=wp-content/uploads/exports/subscriptions-export-sanitized.json
```

Expected output: `Valid: 277 / Total: 277 / Invalid: 0`

### Step 3 — Simulate Mollie (create test customers + mandates)

```bash
wp subs simulate-mollie --file=wp-content/uploads/exports/subscriptions-export-sanitized.json
```

This step:
- Creates a real Mollie Test customer for each unique `cst_dummy_*` ID
- Creates a real Mollie Test mandate for each `mdt_dummy_*` ID
- Stores the mapping in `wp_mollie_test_mapping`

> ⚠️ Must run **before** import. Import will use dummy IDs if this step is skipped.

### Step 4 — Dry run (safe, no changes written)

```bash
wp subs import --file=wp-content/uploads/exports/subscriptions-export-sanitized.json --dry-run --limit=1
```

Check the log to confirm a record would be processed:
```
[DRY-RUN] Would import Pronamic ID 16177 for user@example.com
```

### Step 5 — Real import (1 record first)

```bash
wp subs import --file=wp-content/uploads/exports/subscriptions-export-sanitized.json --limit=1
```

Verify in the log:
```
[INFO] FluentCart subscription created ID 23
[INFO] Mollie subscription created sub_xxxxxxxx
```

Then verify the subscription appears in the **Mollie Test dashboard** (not Live).

### Step 6 — Full import

```bash
wp subs import --file=wp-content/uploads/exports/subscriptions-export-sanitized.json
```

If interrupted, resume without duplicating already-imported records:

```bash
wp subs import --file=wp-content/uploads/exports/subscriptions-export-sanitized.json --resume
```

---

## Verifying in Mollie

> ⚠️ Always check **Test mode** in the Mollie dashboard, not Live mode.

In the Mollie dashboard:
1. Toggle **Test mode** ON (top right)
2. Go to **Customers** — you should see the imported test customers
3. Go to **Subscriptions** — each `sub_xxxxxxxx` ID from the log should appear here

The `vendor_customer_id` stored in FluentCart subscriptions will match the Mollie Test customer ID (`cst_...`), not the original dummy ID.

---

## Available commands

| Command | Description |
|---|---|
| `wp subs mollie-config` | Check Mollie test key is configured |
| `wp subs validate --file=...` | Validate export JSON (277 records) |
| `wp subs simulate-mollie --file=...` | Create Mollie Test customers/mandates + store mapping |
| `wp subs import --file=... [--dry-run] [--limit=N] [--offset=N] [--resume]` | Run import |

---

## Database tables

| Table | Purpose |
|---|---|
| `wp_subscription_migration_map` | Tracks import state per Pronamic ID |
| `wp_mollie_test_mapping` | Maps dummy export IDs → real Mollie Test IDs |

Both tables are created automatically on plugin activation.

---

## Log file

All import activity is logged to:

```
wp-content/uploads/subscription-migration.log
```

Monitor in real time:

```bash
tail -f wp-content/uploads/subscription-migration.log
```

---

## Troubleshooting

### "FluentCart records exist but no Mollie subscriptions"

This means the FluentCart subscription was created but the Mollie API call failed after it.

**Cause:** `simulate-mollie` was not run before import, so no test mapping existed and the dummy IDs were sent to Mollie — which rejected them.

**Fix:**
1. Run `wp subs simulate-mollie --file=...` to create the mapping
2. Check the log for `Mollie API failure:` lines to identify which Pronamic IDs failed
3. Re-run with `--resume` — already-imported records will be skipped, failed ones will be retried

### "Mollie API key not configured"

The `SUBSCRIPTION_MOLLIE_TEST_API_KEY` constant is missing or not a `test_` key.

**Fix:** Add to `wp-config.php`:
```php
define( 'SUBSCRIPTION_MOLLIE_TEST_API_KEY', 'test_yourKeyHere' );
```
Then run `wp subs mollie-config` to confirm.

### "File not found" on validate/import

The JSON file path is relative to the WordPress root (`app/public/`). Make sure:
1. The `exports/` folder exists: `wp-content/uploads/exports/`
2. The file is named exactly `subscriptions-export-sanitized.json`
3. You are running the command from `app/public/`

### Partial failure: FluentCart created, Mollie failed

The log will show:
```
[INFO]  FluentCart subscription created ID 23
[ERROR] Mollie API failure: No mandate found
```

This leaves a FluentCart subscription with no `vendor_subscription_id`. Re-run with `--resume` after fixing the root cause (usually missing simulate-mollie mapping).

---

## Notes

- This plugin is **test-only**. Live Mollie API keys are blocked in `MollieApiClient.php` and will throw an error.
- All Mollie subscriptions created appear in **Mollie Test mode only** — they are not real charges.
- The `config` column on each FluentCart subscription stores both the mapped test IDs and the original dummy export IDs for audit purposes.
